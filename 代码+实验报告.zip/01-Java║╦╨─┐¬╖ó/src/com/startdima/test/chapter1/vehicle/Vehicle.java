package com.startdima.test.chapter1.vehicle;

public interface Vehicle {
	public void start(int arg);

	public void stop(int arg);

}
